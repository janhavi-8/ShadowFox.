<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Developer | Landing Page</title>
    <link rel="stylesheet" href="style.css" />
  </head>
  <body>
    <section class="hero_section">
      <div class="text_container">
        <h2><span class="lg_text">Hi,</span> I am John Doe</h2>
        <h1 class="lg_text">FULL STACK DEVELOPER</h1>
      </div>
    </section>
    <section class="black_box">
      <h2>WORK, I CAN DO FOR <span>YOU</span></h2>
    </section>
    <section class="work">
      <div class="grid_item">
        <div class="card">
          <div class="image_container">
            <img src="images/web.png" alt="web development" />
          </div>
          <div class="card_content">
            <h3>Web Development</h3>
            <p>
              Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ratione
              quibusdam ex quaerat quasi nostrum tempore.
            </p>
          </div>
        </div>
      </div>
      <div class="grid_item">
        <div class="card">
          <div class="image_container">
            <img src="images/mobile.png" alt="app development" />
          </div>
          <div class="card_content">
            <h3>App Development</h3>
            <p>
              Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ratione
              quibusdam ex quaerat quasi nostrum tempore.
            </p>
          </div>
        </div>
      </div>
      <div class="grid_item">
        <div class="card">
          <div class="image_container">
            <img src="images/web.png" alt="web development" />
          </div>
          <div class="card_content">
            <h3>UI UX Design</h3>
            <p>
              Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ratione
              quibusdam ex quaerat quasi nostrum tempore.
            </p>
          </div>
        </div>
      </div>
    </section>
    <section class="bottom_section">
      <div class="contact">
        <h2>Contact Me</h2>
        <p>
          Lorem ipsum dolor sit, amet consectetur adipisicing elit. Nisi dolor,
          esse quasi doloremque temporibus quis.
        </p>
        <p>dosomecoding@example.test</p>
      </div>
      <div class="about">
        <h2>About Me</h2>

        <p>
          Lorem ipsum dolor sit, amet consectetur adipisicing elit. Nisi dolor,
          esse quasi doloremque temporibus quis.
        </p>
        <p>
          Lorem ipsum dolor sit, amet consectetur adipisicing elit. Nisi dolor,
          esse quasi doloremque temporibus quis.
        </p>
      </div>
    </section>
    <footer>Project By do some coding</footer>
  </body>
</html>